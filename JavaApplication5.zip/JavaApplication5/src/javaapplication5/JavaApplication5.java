package javaapplication5;




public class JavaApplication5 {


    public static void main(String[] args) {
        
        Iu1 ui = new Iu1();
        Cola cola = new Cola(ui);
        ui.setVisible(true);      
        
    };
    
    
}